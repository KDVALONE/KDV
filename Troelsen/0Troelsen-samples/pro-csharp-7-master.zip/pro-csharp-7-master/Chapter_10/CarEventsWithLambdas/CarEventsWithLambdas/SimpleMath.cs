﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarEventsWithLambdas
{
    class SimpleMath
    {
        public int Add(int x, int y) =>  x + y;
        public void PrintSum(int x, int y) => Console.WriteLine(x + y);
    }
}
