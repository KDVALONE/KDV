﻿namespace AutoLotDAL3.Models
{
	public class NewCar
	{
		public int CarID { get; set; }
		public string Color { get; set; }
		public string Make { get; set; }
		public string PetName { get; set; }
	}
}